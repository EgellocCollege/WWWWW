package com.hello.myai;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    private static PopupWindow popupWindow;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        final ImageView image = (ImageView)findViewById(R.id.image);
//        // 加载动画资源
//        final Animation anim = AnimationUtils.loadAnimation(this,
//                R.anim.my_anim);
//        // 设置动画结束后保留结束状态
//        anim.setFillAfter(true);  // ①
        Button bn = (Button) findViewById(R.id.bn);



        bn.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View arg0)
            {

                // 尝试 1
                LinearLayout layout = new LinearLayout(MainActivity.this);
                layout.setBackgroundColor(Color.BLUE);


                TextView tv = new TextView(MainActivity.this);
                tv.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
                tv.setText("I'm a pop -----------------------------!");
                tv.setTextColor(Color.RED);
                layout.addView(tv);

                popupWindow = new PopupWindow(layout, 120, 120);

                popupWindow.setFocusable(true);
                popupWindow.setOutsideTouchable(true);
                popupWindow.setBackgroundDrawable(new BitmapDrawable());


                layoutParams1WM = getWindow().getAttributes();
                layoutParams1WM.windowAnimations = android.R.anim.fade_in;
                getWindowManager().addView(layout,layoutParams1WM);


                // 尝试 2
//                addTextViewWindow();

            }
        });

    }
    WindowManager.LayoutParams layoutParams1WM;
    LinearLayout linearLayout;

    private void addTextViewWindow(){

//        Button button = new Button(this);
//        button.setText("addContentView AddBtn");
//        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        addContentView(button, layoutParams);

         linearLayout = new LinearLayout(this);
        Button buttonWM = new Button(this);
        buttonWM.setText("WM addView AddBtnWM");
        WindowManager.LayoutParams layoutParams1L = new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        layoutParams1L.gravity = Gravity.CENTER;

        linearLayout.addView(buttonWM, layoutParams1L);



        layoutParams1WM = getWindow().getAttributes();


        // 方式 1 ， 参数 设置
//        <alpha xmlns:android="http://schemas.android.com/apk/res/android"
//        android:interpolator="@interpolator/decelerate_quad"
//        android:fromAlpha="0.0" android:toAlpha="1.0"
//        android:duration="@android:integer/config_longAnimTime" />

//    <integer name="config_longAnimTime">500</integer>


        layoutParams1WM.windowAnimations = android.R.anim.fade_in;
//      layoutParams1WM.alpha = 0.0f;
        getWindowManager().addView(linearLayout,layoutParams1WM);



        // 方式 2 ， 代码实现
        ValueAnimator anim = ValueAnimator.ofFloat(0.0f, 1.0f);
        anim.setDuration(500);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float currentValue = (float) animation.getAnimatedValue();
                Log.d("TAG", "cuurent value is " + currentValue);
                layoutParams1WM.alpha = currentValue;
                getWindowManager().updateViewLayout(linearLayout,layoutParams1WM);
            }
        });
        anim.start();






//        ObjectAnimator animator = ObjectAnimator.ofFloat(getWindowManager(),
//                "alpha",0,1.0f)
//                .setDuration(3000);
//        animator.start();
    }
}
